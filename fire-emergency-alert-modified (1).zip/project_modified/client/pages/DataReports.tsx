import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  Thermometer,
  Droplet,
  MapPin,
  Clock,
} from "lucide-react";

export default function DataReports() {
  const fireLocations = [
    {
      id: 1,
      name: "Northern Ridge Fire",
      lat: "40.7128",
      lon: "-74.0060",
      intensity: "High",
      area: "2.5 km²",
      progress: "35% contained",
      startTime: "06:30 AM",
      reportedBy: "Automated Sensor Network",
    },
    {
      id: 2,
      name: "Downtown Structure Fire",
      lat: "40.7580",
      lon: "-73.9855",
      intensity: "Medium",
      area: "0.15 km²",
      progress: "Fire department on scene",
      startTime: "11:45 AM",
      reportedBy: "Emergency Call Center",
    },
    {
      id: 3,
      name: "East Valley Brush Fire",
      lat: "40.6892",
      lon: "-74.1445",
      intensity: "Medium",
      area: "1.2 km²",
      progress: "Contained",
      startTime: "09:15 AM",
      reportedBy: "Community Alert System",
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      {/* Page Header */}
      <section className="py-8 md:py-12 bg-gradient-to-br from-primary/5 to-secondary/5 border-b border-border">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Data & Reports
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Real-time sensor data, fire coordinates, and comprehensive alert information
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4 space-y-12">
          {/* DHT11 Live Sensor Data from ThingSpeak */}
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2 flex items-center gap-2">
              <Thermometer size={28} className="text-primary" />
              DHT11 Live Sensor — ThingSpeak Cloud
            </h2>
            <p className="text-muted-foreground mb-6">
              Real-time temperature and humidity readings from the DHT11 sensor streamed via ThingSpeak IoT platform.
            </p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* IR Sensor Live Chart */}
              <div className="bg-card p-6 rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors">
                <div className="flex items-center gap-2 mb-4">
                  <Thermometer size={20} className="text-primary" />
                  <h3 className="text-xl font-bold text-foreground">Live IR Sensor (°C)</h3>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse inline-block"></span>
                    LIVE
                  </span>
                </div>
                <div className="rounded-lg overflow-hidden border border-border">
                  <iframe
                    width="100%"
                    height="260"
                    style={{ border: "none", display: "block" }}
                    src="https://thingspeak.com/channels/3329332/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=IR+Sensor&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="IR Sensor - ThingSpeak"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Auto-refreshes every 15 seconds · Source: ThingSpeak Channel 3329332
                </p>
              </div>

              {/* Humidity Live Chart */}
              <div className="bg-card p-6 rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors">
                <div className="flex items-center gap-2 mb-4">
                  <Droplet size={20} className="text-primary" />
                  <h3 className="text-xl font-bold text-foreground">Live Humidity (%)</h3>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse inline-block"></span>
                    LIVE
                  </span>
                </div>
                <div className="rounded-lg overflow-hidden border border-border">
                  <iframe
                    width="100%"
                    height="260"
                    style={{ border: "none", display: "block" }}
                    src="https://thingspeak.com/channels/3329332/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=DHT11&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="DHT11 Humidity - ThingSpeak"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Auto-refreshes every 15 seconds · Source: ThingSpeak Channel 3329332
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Temperature Live Chart */}
              <div className="bg-card p-6 rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors">
                <div className="flex items-center gap-2 mb-4">
                  <Thermometer size={20} className="text-primary" />
                  <h3 className="text-xl font-bold text-foreground">Live Temperature (°C)</h3>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse inline-block"></span>
                    LIVE
                  </span>
                </div>
                <div className="rounded-lg overflow-hidden border border-border">
                  <iframe
                    width="100%"
                    height="260"
                    style={{ border: "none", display: "block" }}
                    src="https://thingspeak.com/channels/3329332/charts/3?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Temperature&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="Temperature - ThingSpeak"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Auto-refreshes every 15 seconds · Source: ThingSpeak Channel 3329332
                </p>
              </div>

              {/* Distance Sensor Live Chart */}
              <div className="bg-card p-6 rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors">
                <div className="flex items-center gap-2 mb-4">
                  <Thermometer size={20} className="text-primary" />
                  <h3 className="text-xl font-bold text-foreground">Live Distance (m)</h3>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse inline-block"></span>
                    LIVE
                  </span>
                </div>
                <div className="rounded-lg overflow-hidden border border-border">
                  <iframe
                    width="100%"
                    height="260"
                    style={{ border: "none", display: "block" }}
                    src="https://thingspeak.com/channels/3329332/charts/4?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Distance&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="Distance - ThingSpeak"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Auto-refreshes every 15 seconds · Source: ThingSpeak Channel 3329332
                </p>
              </div>

              {/* Smoke Sensor Placeholder */}
              <div className="bg-card p-6 rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors">
                <div className="flex items-center gap-2 mb-4">
                  <Thermometer size={20} className="text-primary" />
                  <h3 className="text-xl font-bold text-foreground">Live Smoke Sensor</h3>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-gray-500 inline-block"></span>
                    OFFLINE
                  </span>
                </div>
                <div className="rounded-lg overflow-hidden border border-border flex items-center justify-center" style={{ height: "260px", backgroundColor: "#f5f5f5" }}>
                  <p className="text-lg font-semibold text-muted-foreground">NO DATA</p>
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Awaiting sensor configuration
                </p>
              </div>
            </div>
          </div>

          {/* Fire Locations with Coordinates */}
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-2">
              <MapPin size={28} className="text-primary" />
              Active Fire Locations
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {fireLocations.map((fire) => (
                <div
                  key={fire.id}
                  className="p-6 bg-card rounded-lg border-2 border-primary/30 hover:border-primary/50 transition-colors"
                >
                  <h3 className="text-xl font-bold text-foreground mb-4">
                    {fire.name}
                  </h3>
                  <div className="space-y-3 mb-4">
                    <div className="p-3 bg-background rounded-lg border border-border">
                      <p className="text-xs text-muted-foreground">Latitude</p>
                      <p className="font-mono font-bold text-primary">{fire.lat}°N</p>
                    </div>
                    <div className="p-3 bg-background rounded-lg border border-border">
                      <p className="text-xs text-muted-foreground">Longitude</p>
                      <p className="font-mono font-bold text-primary">{fire.lon}°W</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-background rounded-lg border border-border">
                        <p className="text-xs text-muted-foreground">Intensity</p>
                        <p className={`font-semibold ${fire.intensity === "High" ? "text-red-600" : "text-yellow-600"
                          }`}>
                          {fire.intensity}
                        </p>
                      </div>
                      <div className="p-3 bg-background rounded-lg border border-border">
                        <p className="text-xs text-muted-foreground">Area</p>
                        <p className="font-semibold text-foreground">{fire.area}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2 pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Status</span>
                      <span className="text-sm font-semibold text-foreground">
                        {fire.progress}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock size={14} />
                      Reported: {fire.startTime}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      By: {fire.reportedBy}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>

      <Footer />
    </div>
  );
}
