import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  Bell,
  Thermometer,
  Droplet,
  Radio,
  Flame,
  MapPin,
  Clock,
  Activity,
  Phone,
} from "lucide-react";

export default function Index() {
  const sensors = [
    {
      id: 1,
      name: "Temperature",
      value: "45°C",
      icon: Thermometer,
      status: "Critical",
      location: "Sector A1",
    },
    {
      id: 2,
      name: "Humidity",
      value: "15%",
      icon: Droplet,
      status: "Low",
      location: "Sector A1",
    },
    {
      id: 3,
      name: "Smoke Density",
      value: "850 AQI",
      icon: Radio,
      status: "Critical",
      location: "Sector A1",
      gasLevel: "HIGH",
      distance: 35,
    },
  ];

  // Gas detection logic
  const getGasStatus = (sensor: any) => {
    if (!sensor.gasLevel || !sensor.distance) return "";

    if (sensor.gasLevel === "HIGH") {
      return "GAS: YES | FIRE DETECTED 🔥";
    } else {
      if (sensor.distance < 50) {
        return "GAS: NO | OBJECT NEARBY";
      }
    }
    return "";
  };

  const currentAlerts = [
    {
      id: 1,
      title: "Fire Alert Detected",
      location: "Northern Ridge Area",
      severity: "High",
      description: "Active fire spreading rapidly, evacuation recommended",
      distance: "0.5 km away",
      coordinates: "40.7128°N, 74.0060°W",
      status: "Active",
    },
    {
      id: 2,
      title: "Fire Alert Detected",
      location: "Downtown District",
      severity: "Medium",
      description: "Fire department responding to commercial building",
      distance: "3 km away",
      coordinates: "40.7580°N, 73.9855°W",
      status: "Responding",
    },
    {
      id: 3,
      title: "Fire Alert Detected",
      location: "Downtown District",
      severity: "Medium",
      description: "Fire department responding to commercial building",
      distance: "3 km away",
      coordinates: "40.7580°N, 73.9855°W",
      status: "Responding",
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      {/* Top Alerts Bar */}
      <section className="bg-primary/10 border-b-2 border-primary/30 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 overflow-x-auto pb-2">
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <Bell size={18} className="text-primary animate-pulse" />
              Current Alerts:
            </div>
            {currentAlerts.map((alert) => (
              <div
                key={alert.id}
                className="flex-shrink-0 px-4 py-2 bg-card rounded-lg border border-primary/30 hover:border-primary/50 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      alert.severity === "High"
                        ? "bg-red-500 animate-pulse"
                        : "bg-yellow-500"
                    }`}
                  />
                  <span className="text-xs font-medium text-foreground">
                    {alert.title}
                  </span>
                  <span className="text-xs text-muted-foreground">({alert.status})</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content - Two Column Layout */}
      <section className="flex-1 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* LEFT SIDE - Description & Sensors */}
            <div className="lg:col-span-1 space-y-6">
              {/* Description Section */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h2 className="text-2xl font-bold text-foreground mb-4">
                  System Overview
                </h2>
                <p className="text-muted-foreground mb-4">
                  FireAlert monitors real-time fire emergencies with advanced sensor networks and rapid response coordination.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Activity size={20} className="text-primary mt-1" />
                    <div>
                      <h4 className="font-semibold text-foreground">Real-time Monitoring</h4>
                      <p className="text-sm text-muted-foreground">24/7 sensor data collection</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Radio size={20} className="text-primary mt-1" />
                    <div>
                      <h4 className="font-semibold text-foreground">Live Updates</h4>
                      <p className="text-sm text-muted-foreground">Instant alert notifications</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin size={20} className="text-primary mt-1" />
                    <div>
                      <h4 className="font-semibold text-foreground">Precise Location</h4>
                      <p className="text-sm text-muted-foreground">GPS coordinates tracking</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sensors Section */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                  <Thermometer size={20} className="text-primary" />
                  Active Sensors
                </h3>

                {/* Temperature */}
                {(() => {
                  const raw = parseFloat(sensors[0].value);
                  const isFire = raw > 50;
                  const isWarn = raw >= 35 && raw <= 50;
                  return (
                    <div className={`mb-3 p-4 rounded-lg border-2 ${isFire ? "border-red-500 bg-red-500/10" : isWarn ? "border-yellow-500 bg-yellow-500/10" : "border-green-500 bg-green-500/10"}`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                          <Thermometer size={13} /> Temperature
                        </span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isFire ? "bg-red-500 text-white" : isWarn ? "bg-yellow-500 text-white" : "bg-green-500 text-white"}`}>
                          {isFire ? "🚨 Fire Likely" : isWarn ? "⚠️ Warning" : "✅ Normal"}
                        </span>
                      </div>
                      <div className={`text-3xl font-black ${isFire ? "text-red-500" : isWarn ? "text-yellow-500" : "text-green-500"}`}>
                        {sensors[0].value}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {isFire ? "> 50°C — fire threshold exceeded" : isWarn ? "35–50°C — elevated risk zone" : "20–35°C — safe range"}
                      </div>
                    </div>
                  );
                })()}

                {/* Humidity */}
                {(() => {
                  const raw = parseFloat(sensors[1].value);
                  const isFire = raw < 20;
                  const isWarn = raw >= 20 && raw < 30;
                  return (
                    <div className={`mb-3 p-4 rounded-lg border-2 ${isFire ? "border-red-500 bg-red-500/10" : isWarn ? "border-yellow-500 bg-yellow-500/10" : "border-green-500 bg-green-500/10"}`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                          <Droplet size={13} /> Humidity
                        </span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isFire ? "bg-red-500 text-white" : isWarn ? "bg-yellow-500 text-white" : "bg-green-500 text-white"}`}>
                          {isFire ? "🚨 Fire Indicator" : isWarn ? "⚠️ Warning" : "✅ Normal"}
                        </span>
                      </div>
                      <div className={`text-3xl font-black ${isFire ? "text-red-500" : isWarn ? "text-yellow-500" : "text-green-500"}`}>
                        {sensors[1].value}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {isFire ? "< 20% — critically dry, fire risk high" : isWarn ? "< 30% — dry conditions, elevated risk" : "30–60% — safe range"}
                      </div>
                    </div>
                  );
                })()}

                {/* Smoke */}
                {(() => {
                  const raw = parseFloat(sensors[2].value);
                  const isFire = raw > 300;
                  const isWarn = raw >= 150 && raw <= 300;
                  return (
                    <div className={`mb-3 p-4 rounded-lg border-2 ${isFire ? "border-red-500 bg-red-500/10" : isWarn ? "border-yellow-500 bg-yellow-500/10" : "border-green-500 bg-green-500/10"}`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                          <Radio size={13} /> Smoke (MQ Sensor)
                        </span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isFire ? "bg-red-500 text-white" : isWarn ? "bg-yellow-500 text-white" : "bg-green-500 text-white"}`}>
                          {isFire ? "🚨 Fire Likely" : isWarn ? "⚠️ Warning" : "✅ Normal"}
                        </span>
                      </div>
                      <div className={`text-3xl font-black ${isFire ? "text-red-500" : isWarn ? "text-yellow-500" : "text-green-500"}`}>
                        {sensors[2].value}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {isFire ? "> 300 ppm — rapid spike, strong fire signal" : isWarn ? "150–300 ppm — smoke detected" : "0–150 ppm — clean air"}
                      </div>
                    </div>
                  );
                })()}

                {/* Fire Alert Trigger Banner */}
                {(() => {
                  const temp = parseFloat(sensors[0].value);
                  const hum = parseFloat(sensors[1].value);
                  const smoke = parseFloat(sensors[2].value);
                  const irFire = sensors[2].gasLevel === "HIGH";
                  const triggered = (temp > 50 && smoke > 300) || (irFire) || (hum < 20 && temp > 35);
                  return triggered ? (
                    <div className="mt-1 mb-3 p-4 rounded-lg border-2 border-red-600 bg-red-600/15 flex items-center gap-3 animate-pulse">
                      <Flame size={22} className="text-red-600 shrink-0" />
                      <div>
                        <p className="text-sm font-black text-red-600 uppercase tracking-wide">🚨 Fire Alert Triggered</p>
                        <p className="text-xs text-red-500 mt-0.5">
                          {temp > 50 && smoke > 300 ? "Temp > 50°C & Smoke > 300 ppm" : irFire ? "IR flame detected" : "Humidity critical + rising temp"}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-1 mb-3 p-3 rounded-lg border border-green-500/40 bg-green-500/5 flex items-center gap-2">
                      <Activity size={16} className="text-green-500 shrink-0" />
                      <p className="text-xs font-semibold text-green-600">No fire alert conditions met</p>
                    </div>
                  );
                })()}

                <Button asChild className="w-full mt-2 bg-primary hover:bg-primary/90">
                  <Link to="/data">View All Sensor Data</Link>
                </Button>
              </div>

              {/* Live Sensor Data from ThingSpeak */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="text-xl font-bold text-foreground mb-2 flex items-center gap-2">
                  <Thermometer size={20} className="text-primary" />
                  DHT11 Live Sensor
                </h3>
                <p className="text-xs text-muted-foreground mb-4">
                  Real-time data from ThingSpeak IoT platform
                </p>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* IR Sensor Chart */}
                  <div className="bg-background rounded-lg border border-border p-3">
                    <h4 className="text-sm font-bold text-foreground mb-2">IR Sensor (°C)</h4>
                    <iframe
                      width="100%"
                      height="180"
                      style={{ border: "none", display: "block", borderRadius: "0.5rem" }}
                      src="https://thingspeak.com/channels/3329332/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=IR+Sensor&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                      title="IR Sensor - ThingSpeak"
                    />
                  </div>

                  {/* Humidity Chart */}
                  <div className="bg-background rounded-lg border border-border p-3">
                    <h4 className="text-sm font-bold text-foreground mb-2">Humidity (%)</h4>
                    <iframe
                      width="100%"
                      height="180"
                      style={{ border: "none", display: "block", borderRadius: "0.5rem" }}
                      src="https://thingspeak.com/channels/3329332/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=DHT11&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                      title="Humidity - ThingSpeak"
                    />
                  </div>
                </div>

                {/* Temperature Chart */}
                <div className="bg-background rounded-lg border border-border p-3 mt-4">
                  <h4 className="text-sm font-bold text-foreground mb-2">Temperature (°C)</h4>
                  <iframe
                    width="100%"
                    height="180"
                    style={{ border: "none", display: "block", borderRadius: "0.5rem" }}
                    src="https://thingspeak.com/channels/3329332/charts/3?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Temperature&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="Temperature - ThingSpeak"
                  />
                </div>

                {/* Distance Sensor Chart */}
                <div className="bg-background rounded-lg border border-border p-3 mt-4">
                  <h4 className="text-sm font-bold text-foreground mb-2">Distance (m)</h4>
                  <iframe
                    width="100%"
                    height="180"
                    style={{ border: "none", display: "block", borderRadius: "0.5rem" }}
                    src="https://thingspeak.com/channels/3329332/charts/4?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Distance&type=line&xaxis=Time&api_key=DQPISRA0QNRN02TD"
                    title="Distance - ThingSpeak"
                  />
                </div>

                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Clock size={12} />
                  Auto-refreshes every 15 seconds
                </p>
              </div>
            </div>

            {/* RIGHT SIDE - Current Fire Alerts */}
            <div className="lg:col-span-2">
              <div
                className="bg-card rounded-lg border border-border p-6 flex flex-col justify-start items-center"
                style={{
                  width: "800px",
                  height: "800px",
                  overflowX: "auto",
                  overflowY: "auto",
                }}
              >
                <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <Flame size={24} className="text-primary" />
                  Active Fire Alerts
                </h2>

                {/* Emergency Switch Section */}
                <div className="bg-gradient-to-br from-red-500/10 to-primary/10 rounded-lg border-2 border-primary/40 mt-6 flex flex-col justify-start items-center p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-foreground flex items-center gap-2">
                      <AlertCircle size={18} className="text-red-600 animate-pulse" />
                      Emergency Access
                    </h3>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">
                    Quick access to active fire alerts and emergency information
                  </p>
                  <a href="https://ba64c9bbffff4fc184c8cb4afdf4e19c-br-3c0651bd502647f288effc1d3.fly.dev/alerts" className="w-full inline-flex items-center justify-center gap-2 animate-pulse bg-red-600 hover:bg-red-700 text-white font-bold rounded-md px-4 py-2">
                    <Flame size={16} />
                    EMERGENCY
                  </a>
                </div>

                <div className="space-y-4 mt-5 w-full">
                  {currentAlerts.map((alert) => (
                    <div
                      key={alert.id}
                      className="p-5 rounded-lg border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span
                              className={`w-3 h-3 rounded-full ${
                                alert.severity === "High"
                                  ? "bg-red-500 animate-pulse"
                                  : "bg-yellow-500"
                              }`}
                            />
                            <h3 className="font-semibold text-lg text-foreground">
                              {alert.title}
                            </h3>
                          </div>
                          <p className="text-sm text-muted-foreground flex items-center gap-2">
                            <MapPin size={14} />
                            {alert.location}
                          </p>
                        </div>
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-primary text-white">
                          {alert.severity}
                        </span>
                      </div>

                      <p className="text-foreground mb-4 text-sm">
                        {alert.description}
                      </p>

                      <div className="grid grid-cols-2 gap-3 mb-4 p-3 bg-background rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">Status</p>
                          <p className="font-semibold text-foreground">{alert.status}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Distance</p>
                          <p className="font-semibold text-foreground">{alert.distance}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-xs text-muted-foreground">Coordinates</p>
                          <p className="font-mono text-sm text-primary">
                            {alert.coordinates}
                          </p>
                        </div>
                      </div>

                      <div className="flex gap-3">
                        <Button
                          asChild
                          size="sm"
                          className="flex-1 bg-primary hover:bg-primary/90 text-white"
                        >
                          <Link to="/emergency" className="flex items-center gap-2">
                            <Phone size={16} />
                            Report / Help
                          </Link>
                        </Button>
                        <Button
                          asChild
                          size="sm"
                          variant="outline"
                          className="flex-1"
                        >
                          <Link to="/data">View Details</Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <Button asChild variant="outline" className="w-full mt-6">
                  <Link to="/alerts" className="flex items-center gap-2">
                    View Complete Alert History
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
